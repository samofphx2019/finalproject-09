from django.urls import path
from . import views

urlpatterns = [
    path('', views.hi, name='myhome-page'),
    path('', views.regist, name='Registraion-page'),
]

#urlpatterns = [
   # path('', views.regist, name='Registraion-page'),
#]
