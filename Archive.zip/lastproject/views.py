from django.shortcuts import render
from django.http import HttpResponse
from . models import RegistrationForm
# Create your views here.

def hi(request):
    return render(request, 'lastproject/userregistration.html')

def regist(request):
    return render(request, 'lastproject/registrationform.html')



def createusers(request):
    post.username =request.POST.get('username')
    post.password =request.POST.get('password')
    post.firstname =request.POST.get('firstname')
    post.middlename =request.POST.get('middlename')
    post.lastname =request.POST.get('lastname')
    post.gender =request.POST.get('gender')
    post.city =request.POST.get('city')
    post.state =request.POST.get('state')
    post.zipcode =request.POST.get('zipcode')
    post.email =request.POST.get('email')
    post.cellphone =request.POST.get('cellphone')
    post.country =request.POST.get('country')
    post.dateofbirth =request.POST.get('dateofbirth')
    post.memeberorganization =request.POST.get('memeberorganization')
    post.save()

