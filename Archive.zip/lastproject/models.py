from django.db import models



class RegistrationForm(models.Model):
    username = models.CharField(label="User Name", max_lenght=200)
    password = models.CharField(label="Password", max_lenght=200)
    firstname = models.CharField(label="Fist Name", max_lenght=200)
    lastname = models.CharField(label="Last Name", max_lenght=200)
    middlename = models.CharField(label="Middle Name", max_lenght=200)
    gender = models.CharField(label="Gender", max_lenght=100)
    address = models.CharField(label="Address", max_lenght=200)
    city = models.CharField(label="City", max_lenght=200)
    state = models.CharField(label="State", max_lenght=200)
    zipcode = models.CharField(label="Zip Code", max_lenght=200)
    email = models.CharField(label="email", max_lenght=200)
    cellphone = models.CharField(label="cellphone", max_lenght=100)
    country = models.CharField(label="Country", max_lenght=200)
    dateofbirth = models.CharField(label="Date Of Birth", max_lenght=100)
    memberogranization = models.CharField(label="Member Organization", max_lenght=200)

class Meta:
		model = Myapps
		fields = ("email", "password", "firstname","lastname","middlename","gender","address","city","state","zipcode","email","cellphone","country","dateofbirth","memberogranization")