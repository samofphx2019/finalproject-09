from django.apps import AppConfig


class LastprojectConfig(AppConfig):
    name = 'lastproject'
